#ifndef __EASY_SETUP_SCAN_H__
#define __EASY_SETUP_SCAN_H__

int scan_and_get_security(unsigned char ch, unsigned char* mac);

#endif /* __EASY_SETUP_SCAN_H__ */
